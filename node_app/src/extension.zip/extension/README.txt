1. Open Google Chrome in your browser.
2. Go to Extensions and switch on Developer Mode.
3. Add custom extension and upload the chrome-ext folder in it.
4. DONE